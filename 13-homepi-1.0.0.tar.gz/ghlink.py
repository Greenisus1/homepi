'''GitHub device-flow link for Home Pi recovery. Public client id only;
the token is used for one whoami call and NEVER stored.'''
import json, time, urllib.parse, urllib.request

CLIENT_ID = 'Ov23liE4ISwOOwp2coRn'   # fetchwing OAuth app, public id, device flow
DEVICE_URL = 'https://github.com/login/device/code'
TOKEN_URL = 'https://github.com/login/oauth/access_token'
USER_URL = 'https://api.github.com/user'
SCOPE = 'read:user'


def _post(url, data):
    body = urllib.parse.urlencode(data).encode()
    req = urllib.request.Request(url, data=body,
                                 headers={'Accept': 'application/json'})
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.loads(r.read())


def request_code():
    d = _post(DEVICE_URL, {'client_id': CLIENT_ID, 'scope': SCOPE})
    return {'device_code': d['device_code'], 'user_code': d['user_code'],
            'verification_uri': d['verification_uri'],
            'expires_in': d.get('expires_in', 900), 'interval': d.get('interval', 5)}


def poll_token(device_code, interval=5, expires_in=900):
    '''Returns the token string, or None on timeout/denial.'''
    deadline = time.time() + expires_in
    while time.time() < deadline:
        d = _post(TOKEN_URL, {'client_id': CLIENT_ID, 'device_code': device_code,
                              'grant_type': 'urn:ietf:params:oauth:grant-type:device_code'})
        if 'access_token' in d:
            return d['access_token']
        err = d.get('error')
        if err == 'authorization_pending':
            time.sleep(interval)
            continue
        if err == 'slow_down':
            interval += 5
            time.sleep(interval)
            continue
        return None
    return None


def whoami(token):
    req = urllib.request.Request(USER_URL, headers={
        'Authorization': 'Bearer %s' % token, 'Accept': 'application/json',
        'User-Agent': 'homepi'})
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.loads(r.read()).get('login')


def link_login(fake=None):
    '''Full flow: returns github login string or None. fake=(login) for demo/tests.'''
    if fake is not None:
        return fake
    code = request_code()
    token = poll_token(code['device_code'], code['interval'], code['expires_in'])
    if not token:
        return None
    return whoami(token)   # token discarded here, never stored
