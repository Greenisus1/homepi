'''Event-driven PTY test: first-boot wizard then login, in demo mode.'''
import fcntl, os, pty, re, select, struct, subprocess, tempfile, termios, time

HERE = os.path.dirname(os.path.abspath(__file__))
BUF = bytearray()


def wait_out(fd, patterns, timeout=20):
    need = {p: False for p in patterns}
    end = time.time() + timeout
    while time.time() < end:
        r, _, _ = select.select([fd], [], [], 0.2)
        if fd in r:
            try:
                BUF.extend(os.read(fd, 65536))
            except OSError:
                pass
        text = BUF.decode('utf-8', 'replace')
        for p in need:
            if not need[p] and re.search(p, text):
                need[p] = True
        if all(need.values()):
            return
    raise SystemExit('TIMEOUT waiting for %s' % [p for p, v in need.items() if not v])


def spawn(home):
    master, slave = pty.openpty()
    fcntl.ioctl(slave, termios.TIOCSWINSZ, struct.pack('HHHH', 40, 120, 0, 0))
    env = dict(os.environ, TERM='xterm-256color', HOMEPI_DEMO='1', HOME=home)
    p = subprocess.Popen(['python3', os.path.join(HERE, 'homepiauth.py')],
                         stdin=slave, stdout=slave, stderr=slave, env=env,
                         close_fds=True)
    os.close(slave)
    fcntl.fcntl(master, fcntl.F_SETFL, os.O_NONBLOCK)
    return p, master


def type_text(fd, text):
    os.write(fd, text.encode())
    time.sleep(0.3)


def main():
    home = tempfile.mkdtemp()
    os.environ['HOMEPI_DEMO_ROOT'] = home
    p, m = spawn(home)
    try:
        wait_out(m, [r'first boot setup', r'username \[root\]'])
        type_text(m, '\r')                                   # Enter = root
        wait_out(m, [r'Password rules', r'forget it, reset is HARD'])
        type_text(m, 'weak\r')                               # too weak
        wait_out(m, [r'Missing:'])
        type_text(m, 'Bear!2026x\r')                         # good
        wait_out(m, [r'repeat it'])
        type_text(m, 'Bear!2026x\r')
        wait_out(m, [r'Do you KNOW it by heart\?'])
        type_text(m, 'c')                                    # change it first
        wait_out(m, [r'new password'])
        type_text(m, 'Goose!2026y\r')
        wait_out(m, [r'repeat it'])
        type_text(m, 'Goose!2026y\r')
        wait_out(m, [r'Do you KNOW it by heart\?'])
        type_text(m, 'y')
        wait_out(m, [r'Salted hash|salted hash|Saved', r'i-fi setup'])
        type_text(m, 'e')                                    # ethernet, skip wifi
        wait_out(m, [r'recovery key', r'\[DEMO\] linked as Greenisus1',
                     r'Setup done'])
        type_text(m, 'x')
        deadline = time.time() + 10
        while time.time() < deadline and p.poll() is None:
            time.sleep(0.1)
        if p.poll() is None:
            p.kill()
            raise SystemExit('FAIL: wizard did not exit')
        if p.returncode != 0:
            raise SystemExit('FAIL: wizard exit %d' % p.returncode)
    finally:
        if p.poll() is None:
            p.kill()
        os.close(m)
    # second boot: login with wrong then right password
    global BUF
    BUF = bytearray()
    p, m = spawn(home)
    try:
        wait_out(m, [r'Home Pi - log in'])
        type_text(m, 'root\r')
        type_text(m, 'Wrong!123\r')
        wait_out(m, [r'Wrong login'])
        type_text(m, '\r')
        wait_out(m, [r'username:'])
        type_text(m, 'root\r')
        type_text(m, 'Goose!2026y\r')
        deadline = time.time() + 10
        while time.time() < deadline and p.poll() is None:
            time.sleep(0.1)
        if p.poll() != 0:
            raise SystemExit('FAIL: login exit %s' % p.poll())
        print('PTY PASS')
    finally:
        if p.poll() is None:
            p.kill()
        os.close(m)


if __name__ == '__main__':
    main()
