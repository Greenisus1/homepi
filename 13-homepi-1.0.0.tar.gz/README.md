# Home Pi

Your own Linux distro for the Raspberry Pi 5. Not a layer on someone else's OS: Home Pi builds its own flashable image with [Buildroot](https://buildroot.org) - the Raspberry Pi kernel source, a minimal busybox userland, and a fullscreen terminal "Home" launcher as the login screen, with his Pi App Store apps on the menu. MIT, Greenisus1 / WinnieGaming.

## Honest security note

The login gate is a friendly lock for a single-user appliance, not a real security boundary: anyone with physical access can mount the SD card and edit `/etc/homepi/auth.json`. Recovery depends entirely on the linked GitHub account (and needs network); if that account is lost too, the password cannot be reset. The GitHub token from the QR flow is used once and never stored - only the account name is kept.

## Honest status

- The distro **definition** (this repo: defconfig, overlay, launcher, build script) is original and ours.
- The kernel is the Raspberry Pi Foundation's fork of Linux (`raspberrypi/linux`), Linux is GPL - see the kernel's own license. Home Pi is a distro built from these parts, like a tiny Debian of our own.
- **Not yet boot-tested.** The image has not been flashed or booted on real hardware. First boot on the real Pi is the first real test, and it will be done carefully with the SD card, never by wiping his working card. A flashable image is only produced by running the build below; none is shipped in this repo.

## What's in the image

- `homepi` fullscreen launcher (curses, zero deps) as the login screen on console/tty1: his App Store apps as menu entries, plus App Store, Shell, Reboot and Power off (both behind a confirm). esc exits to a normal shell.
- Rebrand: hostname `homepi`, `/etc/os-release` NAME="Home Pi" (ID fields untouched), login banner and motd with Greenisus1 / WinnieGaming branding.
- First-boot wizard + login (launcher-level lock for a single-user box): asks a username (Enter = root), then a password that needs 8+ chars, one capital, one number, one special - with the plain warning that forgetting it makes reset hard. You confirm you know it (or change it) before it's saved as a salted PBKDF2 hash, never plaintext. Then Wi-Fi (writes wpa_supplicant.conf) or ethernet. Then it links your GitHub by QR device flow - that GitHub account is the recovery key. Later boots ask for the login; "forgot" runs the GitHub QR again and only the SAME linked account can set a new password. Login attempts rate-limit with doubling lockouts.
- Custom boot screen: the WinnieGaming bear logo with "Made by Greenisus1" and "Home Pi is based on Linux" on the framebuffer while the system boots (`fbv`, `S01splash`, image at `/usr/share/homepi/splash.png`, composed in `make-splash.py`). The same credits show in the launcher.
- python3 + curses, dropbear (SSH from his Mac), DHCP on eth0.
- His published Pi Store apps fetched into `/root/apps` at build time by `fetch-apps.sh` (skips any repo that isn't public yet).

## Build

On a Debian/Linux machine with 8G+ RAM, ~15G free disk and a few hours:

```
./build.sh
```

This clones Buildroot, applies `buildroot-external/configs/homepi_pi5_defconfig` (layered on Buildroot's raspberrypi5 defconfig, external Bootlin toolchain so no from-scratch gcc build), fetches the apps, and builds `buildroot/output/images/sdcard.img`.

The Linux repo itself was requested: `./build.sh` with `HOMEPI_KERNEL_LOCAL=1` clones `raspberrypi/linux` (branch rpi-6.12.y, Pi 5 = bcm2712, aarch64) into `kernel/`, and the defconfig comments show the two-line switch to build from that local tree instead of the pinned tarball.

## Flash (only when the Pi is back and he says go)

```
sudo dd if=buildroot/output/images/sdcard.img of=/dev/sdX bs=4M status=progress conv=fsync
```

Get `/dev/sdX` right; it erases the whole card. Use a SPARE microSD, never his working card.

## Layout

- `homepi.py`, `homepilib.py` - launcher + library (unit + PTY tested on x86-64)
- `buildroot-external/` - the BR2_EXTERNAL tree: defconfig, post-build branding, rootfs overlay (inittab autologin, .profile hook, motd, config, `/usr/bin/homepi`)
- `build.sh`, `fetch-apps.sh`, `make-splash.py` - the build pipeline and splash composer
- `kernel/` - the raspberrypi/linux clone (build input, gitignored)

## License

MIT - Greenisus1 (for the Home Pi definition; each bundled part keeps its own license).
