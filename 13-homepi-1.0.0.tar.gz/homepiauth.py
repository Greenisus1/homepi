#!/usr/bin/env python3
'''Home Pi first-boot wizard + login gate (fullscreen curses).
First boot: username (Enter = root) -> password rules + warning -> confirm you
know it -> wifi/ethernet -> link GitHub by QR (the recovery key).
Later boots: login, or "forgot" -> GitHub QR with the SAME linked account ->
set a new password.'''
import curses, getpass, os, subprocess, sys, time

import authlib, ghlink, qr

VERSION = '1.0.0'
DEMO = os.environ.get('HOMEPI_DEMO') == '1'
ROOT = os.environ.get('HOMEPI_DEMO_ROOT', '/tmp/homepi-demo') if DEMO else '/'


def prompt(scr, y, label, secret=False):
    curses.echo(0 if secret else 1)
    scr.addstr(y, 2, label)
    scr.refresh()
    win = curses.newwin(1, 40, y, 2 + len(label))
    win.refresh()
    text = ''
    while True:
        k = win.getch()
        if k in (10, 13, curses.KEY_ENTER):
            break
        if k in (27,):
            curses.noecho()
            return None
        if k in (curses.KEY_BACKSPACE, 127, 8):
            text = text[:-1]
        elif 32 <= k < 127:
            text += chr(k)
        win.erase()
        win.addstr(0, 0, ('*' * len(text)) if secret else text)
        win.refresh()
    curses.noecho()
    return text


def draw_qr(scr, y0, text):
    matrix = qr.encode(text)
    for i, row in enumerate(matrix):
        line = ''.join('██' if v else '  ' for v in row)
        if y0 + i < scr.getmaxyx()[0] - 1:
            scr.addstr(y0 + i, 4, line)


def wizard(scr):
    scr.erase()
    scr.addstr(1, 2, 'Welcome to Home Pi - first boot setup', curses.A_BOLD)
    scr.addstr(3, 2, 'Choose a username. Press Enter for the default: root')
    u = prompt(scr, 4, 'username [root]: ')
    username = (u or '').strip() or 'root'
    while True:
        scr.addstr(6, 2, 'Password rules: 8+ chars, 1 capital, 1 number, 1 special.')
        scr.addstr(7, 2, 'WARNING: if you forget it, reset is HARD (GitHub QR only).',
                   curses.A_BOLD)
        pw = prompt(scr, 8, 'new password: ', secret=True)
        if pw is None:
            continue
        problems = authlib.check_password_rules(pw)
        if problems:
            scr.addstr(9, 2, 'Missing: ' + ', '.join(problems) + '   ')
            scr.refresh()
            time.sleep(1.5)
            scr.move(8, 0)
            continue
        pw2 = prompt(scr, 10, 'repeat it: ', secret=True)
        if pw != pw2:
            scr.addstr(11, 2, 'Did not match, try again.   ')
            scr.refresh()
            time.sleep(1.2)
            continue
        while True:
            scr.addstr(12, 2, 'Do you KNOW it by heart? [y]es keep it / [c]hange it ')
            scr.refresh()
            k = scr.getch()
            if k in (ord('y'), ord('Y')):
                break
            if k in (ord('c'), ord('C')):
                pw = None
                break
        if pw:
            break
    authlib.save_auth(ROOT, username, pw)
    scr.addstr(14, 2, 'Saved (salted hash only - never stored as text).')
    scr.addstr(16, 2, 'Network: [w]i-fi setup  /  [e]thernet (skip) ')
    scr.refresh()
    k = scr.getch()
    if k in (ord('w'), ord('W')):
        ssid = prompt(scr, 17, 'wifi name (SSID): ')
        wpw = prompt(scr, 18, 'wifi password: ', secret=True)
        if ssid and not DEMO:
            conf = ('network={\n  ssid="%s"\n  psk="%s"\n}\n'
                    % (ssid.replace('"', ''), (wpw or '').replace('"', '')))
            try:
                with open('/etc/wpa_supplicant.conf', 'w') as f:
                    f.write(conf)
                subprocess.run(['wpa_supplicant', '-B', '-i', 'wlan0',
                                '-c', '/etc/wpa_supplicant.conf'], check=False)
                subprocess.run(['udhcpc', '-i', 'wlan0', '-q'], check=False)
            except Exception:
                pass
        scr.addstr(19, 2, 'wifi: attempting connection to %s   ' % (ssid or '?'))
    else:
        scr.addstr(17, 2, 'ethernet: nothing to do.   ')
    scr.addstr(21, 2, 'Last step: link your GitHub (recovery key if you forget the password).')
    scr.addstr(22, 2, 'Scan the QR with your phone and approve. [s]kip ')
    scr.refresh()
    login = None
    if DEMO:
        login = ghlink.link_login(fake='Greenisus1')
        scr.addstr(23, 2, '[DEMO] linked as %s   ' % login)
        scr.refresh()
        time.sleep(1)
    else:
        k = scr.getch()
        if k not in (ord('s'), ord('S')):
            code = ghlink.request_code()
            scr.addstr(23, 2, 'Code: %s   (or open %s)' % (code['user_code'], code['verification_uri']))
            draw_qr(scr, 24, code['verification_uri'])
            scr.refresh()
            token = ghlink.poll_token(code['device_code'], code['interval'],
                                      code['expires_in'])
            login = ghlink.whoami(token) if token else None
            if login:
                authlib.set_github_login(ROOT, login)
                scr.addstr(23, 2, 'Linked GitHub: %s - this account is your recovery key.   ' % login)
            else:
                scr.addstr(23, 2, 'No link made; recovery will NOT be available.   ')
            scr.refresh()
            time.sleep(1.5)
    scr.addstr(scr.getmaxyx()[0] - 2, 2, 'Setup done - press any key for the Home screen')
    scr.refresh()
    scr.getch()
    return 0


def login(scr, rec):
    limiter = authlib.RateLimiter()
    while True:
        scr.erase()
        scr.addstr(1, 2, 'Home Pi - log in', curses.A_BOLD)
        if limiter.blocked():
            scr.addstr(4, 2, 'Too many tries. Wait %ds.   ' % limiter.blocked_seconds())
            scr.refresh()
            time.sleep(1)
            continue
        u = prompt(scr, 3, 'username: ')
        if u is None:
            return 2
        p = prompt(scr, 4, 'password: ', secret=True)
        ok = (u == rec['username']
              and authlib.verify_password(p or '', rec['salt'], rec['hash']))
        limiter.record(ok)
        if ok:
            return 0
        scr.addstr(6, 2, 'Wrong login. [enter] retry, [f]orgot password ')
        scr.refresh()
        k = scr.getch()
        if k in (ord('f'), ord('F')):
            if not rec.get('github_login'):
                scr.addstr(7, 2, 'No GitHub recovery was linked at setup. Cannot reset.   ')
                scr.refresh()
                time.sleep(2)
                continue
            scr.addstr(7, 2, 'Verify with GitHub: scan the QR and approve with the LINKED account.')
            scr.refresh()
            if DEMO:
                login_name = ghlink.link_login(fake='Greenisus1')
            else:
                code = ghlink.request_code()
                scr.addstr(8, 2, 'Code: %s' % code['user_code'])
                draw_qr(scr, 9, code['verification_uri'])
                scr.refresh()
                token = ghlink.poll_token(code['device_code'], code['interval'],
                                          code['expires_in'])
                login_name = ghlink.whoami(token) if token else None
            if login_name and login_name.lower() == rec['github_login'].lower():
                scr.addstr(8, 2, 'Verified %s. Set a new password.   ' % login_name)
                scr.refresh()
                while True:
                    npw = prompt(scr, 9, 'new password: ', secret=True)
                    problems = authlib.check_password_rules(npw or '')
                    if problems:
                        scr.addstr(10, 2, 'Missing: ' + ', '.join(problems) + '   ')
                        scr.refresh()
                        time.sleep(1.5)
                        continue
                    authlib.save_auth(ROOT, rec['username'], npw,
                                      rec.get('github_login'))
                    rec = authlib.load_auth(ROOT)
                    scr.addstr(10, 2, 'Password changed. Log in.   ')
                    scr.refresh()
                    time.sleep(1.2)
                    break
            else:
                scr.addstr(8, 2, 'That was not the linked GitHub account. No reset.   ')
                scr.refresh()
                time.sleep(2)


def main():
    if '--version' in sys.argv:
        print(VERSION)
        return 0
    rec = authlib.load_auth(ROOT)
    try:
        if rec is None:
            return curses.wrapper(wizard)
        return curses.wrapper(login, rec)
    except KeyboardInterrupt:
        return 2


if __name__ == '__main__':
    sys.exit(main())
